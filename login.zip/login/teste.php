<?php
include('protect.php');
echo $_SESSION['nome'];
?>