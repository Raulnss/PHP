<?php
$n1=$_POST['n1'];
echo "seu numero vezes 1 = ".$n1*1;
echo "seu numero vezes 2 = ".$n1*2;
echo "seu numero vezes 3 = ".$n1*3;
echo "seu numero vezes 4 = ".$n1*4;
echo "seu numero vezes 5 = ".$n1*5;
echo "seu numero vezes 6 = ".$n1*6;
echo "seu numero vezes 7 = ".$n1*7;
echo "seu numero vezes 8 = ".$n1*8;
echo "seu numero vezes 9 = ".$n1*9;
echo "seu numero vezes 10 = ".$n1*10;
?>