<?php
$n1=$_POST['n1'];
$n=$n1%2;
if ($n==0) {
    echo "numero par";
} else {
    echo "numero impar";
}
?>