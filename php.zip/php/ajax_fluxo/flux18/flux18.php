<?php
$n1=$_POST['n1'];
$ma=$n1+1;
$me=$n1-1;
echo "sucessor = ".$ma;
echo "antecessor = ".$me;
?>