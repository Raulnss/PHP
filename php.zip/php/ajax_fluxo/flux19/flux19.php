<?php
$n1=$_POST['n1'];
$n2=$_POST['n2'];
$r=$n1;
$n1=$n2;
$n2=$r;
echo $n1;
echo $n2;
?>