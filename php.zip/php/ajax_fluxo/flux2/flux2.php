<?php
$n1= $_POST['n1'];
$n2= $_POST['n2'];
$n = 2024-$n2;
echo "ola ".$n1." de ".$n." anos";
?>