<?php
$n1=$_POST['n1'];
$n= (9*$n1+160)/5;
echo $n;
?>