<?php
$n1 = $_POST['n1'];
$n2 = $_POST['n2'];
  $s=$n1+$n2;
  $su=$n1-$n2;
  echo "a soma = ".$s."<br>";
  echo "a subtracao = ".$su."<br>";
  echo "a multiplicacao = ".$n1*$n2."<br>";
  echo "a divisao = ".$n1/$n2."<br>";
  echo "o resto de divisao = ".$n1%$n2."<br>";
?>