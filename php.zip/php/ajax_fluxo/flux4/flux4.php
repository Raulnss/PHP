<?php
$n1 = $_POST['n1'];
$n=$n1+$n1;
echo "o dobro = ".$n;
?>