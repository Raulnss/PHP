<?php
$n1 = $_POST['n1'];
echo "o quadrado = ".$n1*$n1;
?>