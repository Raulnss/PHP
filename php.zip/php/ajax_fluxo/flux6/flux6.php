<?php
$n1 = $_POST['n1'];
echo "o cubo = ".$n1*$n1*$n1;
?>