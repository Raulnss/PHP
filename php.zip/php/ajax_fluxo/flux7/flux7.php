<?php
$n1 = $_POST['n1'];
echo "area = ".$n1*$n1. " perimetro = ";
echo $n1+$n1+$n1+$n1;
?>