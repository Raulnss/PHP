<?php
$n1 = $_POST['n1'];
$n2 = $_POST['n2'];
echo "area = ".$n1*$n2;
echo " perimetro = ".$n1*$n2*$n1*$n2;
?>