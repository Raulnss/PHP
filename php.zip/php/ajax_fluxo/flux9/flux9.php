<?php
$n1=$_POST['n1'];
$n2=$_POST['n2'];
$n=($n1*$n2)/2;
echo "a area = ".$n;
?>