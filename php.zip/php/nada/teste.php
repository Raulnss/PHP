<?php
$se = 863;
$data = $_POST['data2'];
if ($data == $se) {
    echo "Olá parabes" ;
} else {
    echo "Olá voce errol";
}
?>
