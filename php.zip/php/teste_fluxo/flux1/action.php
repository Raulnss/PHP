<?php
      $n1=$_POST['n1'];
      echo "<p>".$n1."</p>"
    ?>