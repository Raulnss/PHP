<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="fluxac10.php" method="post">
        <input type="number" name="n1" id="n1">
        <input type="number" name="n2" id="n2">
        <input type="number" name="n3" id="n3">
        <input type="number" name="n4" id="n4">
        <input type="number" name="n5" id="n5">
        <button type="submit">clique</button>
    </form>
</body>
</html>