<?php
$n1=$_POST['n1'];
$a=$n1*5.20;
echo "voce tem=".$a;
?>