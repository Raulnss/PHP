<?php
$n1=$_POST['n1'];
echo "vesez 1=".$n1*1;
echo "vesez 2=".$n1*2;
echo "vesez 3=".$n1*3;
echo "vesez 4=".$n1*4;
echo "vesez 5=".$n1*5;
echo "vesez 6=".$n1*6;
echo "vesez 7=".$n1*7;
echo "vesez 8=".$n1*8;
echo "vesez 9=".$n1*9;
echo "vesez 10=".$n1*10;
?>