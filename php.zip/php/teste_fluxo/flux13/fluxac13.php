<?php
$n1=$_POST['n1'];
$n2=$_POST['n2'];
echo "a divisao e=".$n1/$n2;
echo "o resto e=".$n1%$n2;
?>