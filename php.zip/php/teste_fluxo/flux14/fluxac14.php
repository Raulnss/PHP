<?php
$n1=$_POST['n1'];
$a=$n1+1;
echo "sucessor=".$a;
?>