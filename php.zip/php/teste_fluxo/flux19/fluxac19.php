<?php
$n1=$_POST['n1'];
$r=$n1%2;
if ($r == 0) {
    echo "o numero e par";
} else {
    echo "o numero e impar";
}

?>