<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="fluxac2.php" method="post">
        <input type="text" name="n1" placeholder="nome">
        <input type="text" name="n2" placeholder="idade">
        <button type="submit">enviar</button>
    </form>
</body>
</html>