<?php
$n1=$_POST['n1'];
$r=$n1+1;
$s=$n1-1;
    echo "sucessor".$r;
    echo "antecessor" .$s;
?>