<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="fluxac21.php" method="post">
        <input type="number" name="n1">
        <input type="number" name="n2">
        <button type="submit">calcular</button>
    </form>
</body>
</html>