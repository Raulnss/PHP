<?php
$n1=$_POST['n1'];
$r=(9*$n1+160)/5;
echo "em farenhait ".$r;
?>