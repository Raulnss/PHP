<?php
      $n1 = $_POST['n1'];
      $n2 = $_POST['n2'];
      $s=$n1+$n2;
      $su=$n1-$n2;
      print "a soma=".$s."<br>";
      print "a subtracao=".$su."<br>";
      print "a multiplicacao=".$n1*$n2."<br>";
      print "a divisao=".$n1/$n2."<br>";
      print "o resto de divisao=".$n1%$n2."<br>";
    ?>