<?php
$n1=$_POST['n1'];
echo "o quadrado e".$n1*$n1;
?>