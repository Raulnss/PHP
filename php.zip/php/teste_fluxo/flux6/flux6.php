<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="fluxac6.php" method="post">
        cubo
        <input type="number" name="n1" id="n1">
        <button type="submit">clicar</button>
    </form>
</body>
</html>