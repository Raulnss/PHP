<?php
$n1=$_POST['n1'];
$s=$n1*$n1*$n1;
echo "o cubo e=".$s;
?>