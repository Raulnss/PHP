<?php
$n1=$_POST['n1'];
$s=$n1+$n1+$n1+$n1;
$a=$n1*$n1;
echo "a area e=".$a;
echo "o perimetro e=".$s;
?>