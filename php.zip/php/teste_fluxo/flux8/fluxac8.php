<?php
$n1=$_POST['n1'];
$n2=$_POST['n2'];
$s=$n1+$n2+$n1+$n2;
$a=$n1*$n2;
echo "a area e=".$a;
echo "o perimetro e=".$s;
?>