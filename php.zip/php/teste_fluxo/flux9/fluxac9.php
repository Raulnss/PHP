<?php
$n1=$_POST['n1'];
$n2=$_POST['n2'];
$a=$n1*$n2;
$s=$a/2;
echo "a area e=".$s;
?>